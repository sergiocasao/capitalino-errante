<?php get_header(); ?>
<?php get_template_part('loop'); ?>
<?php get_footer(); ?>